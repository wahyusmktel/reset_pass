

<?php $__env->startSection('title', 'Import Siswa'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="mb-4">Import Data Siswa dari Excel</h1>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php elseif(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <form action="<?php echo e(route('siswa.import.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="file" class="form-label">Pilih File Excel</label>
            <input type="file" name="file" id="file" class="form-control" required>
            <small class="text-muted">Format: xlsx | <a href="<?php echo e(asset('template/template_import_siswa.xlsx')); ?>">Download
                    Template</a></small>
        </div>
        <button class="btn btn-primary">Import</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Projects\reset-password\resources\views/siswa/import.blade.php ENDPATH**/ ?>