

<?php $__env->startSection('title', 'Edit Jurusan'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="mb-3">
        Edit Jurusan</h1>
    <a href="<?php echo e(route('jurusan.index')); ?>" class="btn btn-secondary mb-3">← Kembali</a>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($e); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('jurusan.update', $jurusan->id)); ?>" method="POST" class="card p-4 shadow bg-white">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label class="form-label">Nama Jurusan</label>
            <input type="text" name="nama_jurusan" class="form-control"
                value="<?php echo e(old('nama_jurusan', $jurusan->nama_jurusan)); ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Kode Jurusan</label>
            <input type="text" name="kode_jurusan" class="form-control"
                value="<?php echo e(old('kode_jurusan', $jurusan->kode_jurusan)); ?>" required>
        </div>
        <button type="submit" class="btn btn-success">Update</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Projects\reset-password\resources\views/jurusan/edit.blade.php ENDPATH**/ ?>