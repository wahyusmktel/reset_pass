

<?php $__env->startSection('title', 'Edit Rombel'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="mb-3">
        Edit Rombel</h1>
    <a href="<?php echo e(route('rombel.index')); ?>" class="btn btn-secondary mb-3">← Kembali</a>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($e); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('rombel.update', $rombel->id)); ?>" method="POST" class="card p-4 shadow bg-white">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label class="form-label">Siswa</label>
            <select name="siswa_id" class="form-select" required>
                <?php $__currentLoopData = $siswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($siswa->id); ?>"
                        <?php echo e(old('siswa_id', $rombel->siswa_id) == $siswa->id ? 'selected' : ''); ?>>
                        <?php echo e($siswa->nama); ?> (<?php echo e($siswa->nis); ?>)
                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label">Kelas</label>
            <select name="kelas_id" class="form-select" required>
                <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($k->id); ?>"
                        <?php echo e(old('kelas_id', $rombel->kelas_id) == $k->id ? 'selected' : ''); ?>>
                        <?php echo e($k->nama_kelas); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <button type="submit" class="btn btn-success">Update</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Projects\reset-password\resources\views/rombel/edit.blade.php ENDPATH**/ ?>