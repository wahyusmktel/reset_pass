<?php $__env->startSection('title', 'Daftar User Google Workspace'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="mb-4">Daftar User Google Workspace</h1>

    <div class="mb-3">
        <a href="<?php echo e(route('admin.google.users', ['refresh' => 1])); ?>" class="btn btn-sm btn-outline-danger">
            🔄 Refresh Cache User
        </a>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    
    <form method="GET" class="row g-3 mb-3">
        <div class="col-md-4">
            <input type="text" name="q" class="form-control" value="<?php echo e(request('q')); ?>"
                placeholder="Cari nama atau email...">
        </div>
        <div class="col-md-2">
            <button class="btn btn-outline-secondary w-100">Cari</button>
        </div>
    </form>

    
    <table class="table table-bordered bg-white shadow">
        <thead class="table-dark">
            <tr>
                <th>Email</th>
                <th>Nama</th>
                <th>Status</th>
                <th>Login Terakhir</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            
            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($user['email']); ?></td>
                    <td><?php echo e($user['name']); ?></td>
                    <td>
                        <span class="badge <?php echo e($user['suspended'] ? 'bg-danger' : 'bg-success'); ?>">
                            <?php echo e($user['suspended'] ? 'Suspended' : 'Aktif'); ?>

                        </span>
                    </td>
                    <td>
                        <?php echo e($user['last_login'] ? \Carbon\Carbon::parse($user['last_login'])->format('d M Y H:i') : '-'); ?>

                    </td>
                    <td>
                        <a href="<?php echo e(route('admin.google-users.show', $user['id'])); ?>"
                            class="btn btn-sm btn-primary">Detail</a>
                        <button type="button" class="btn btn-sm btn-warning" data-bs-toggle="modal"
                            data-bs-target="#resetModal<?php echo e($user['id']); ?>">
                            Reset
                        </button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="text-center text-muted">Tidak ada data ditemukan.</td>
                </tr>
            <?php endif; ?>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                

                <!-- Modal Reset Password -->
                <div class="modal fade" id="resetModal<?php echo e($user['id']); ?>" tabindex="-1"
                    aria-labelledby="resetModalLabel<?php echo e($user['id']); ?>" aria-hidden="true">
                    <div class="modal-dialog">
                        <form method="POST" action="<?php echo e(route('admin.google-users.reset', $user['id'])); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Reset Password: <?php echo e($user['email']); ?></h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Tutup"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="mb-3">
                                        <label>Password Baru</label>
                                        <div class="input-group">
                                            <input type="text" class="form-control" name="password"
                                                id="passwordInput<?php echo e($user['id']); ?>" required>
                                            <button type="button" class="btn btn-outline-secondary"
                                                onclick="generatePassword('<?php echo e($user['id']); ?>')">Generate</button>
                                            <button type="button" class="btn btn-outline-success"
                                                onclick="copyToClipboard('passwordInput<?php echo e($user['id']); ?>')">Copy</button>
                                        </div>
                                        <div class="form-text">Anda bisa mengisi manual atau klik "Generate" untuk membuat
                                            otomatis.</div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary">Reset Password</button>
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    
    <?php if($users instanceof \Illuminate\Pagination\LengthAwarePaginator): ?>
        <?php echo e($users->links()); ?>

    <?php endif; ?>

    <?php $__env->startPush('scripts'); ?>
        <script>
            function generatePassword(id) {
                const pass = Math.random().toString(36).slice(-8); // 8 digit random
                document.getElementById('passwordInput' + id).value = pass;
            }

            function copyToClipboard(inputId) {
                const input = document.getElementById(inputId);
                input.select();
                input.setSelectionRange(0, 99999);
                document.execCommand("copy");
            }
        </script>
    <?php $__env->stopPush(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Project Web\reset-password\resources\views/admin/google-users/index.blade.php ENDPATH**/ ?>