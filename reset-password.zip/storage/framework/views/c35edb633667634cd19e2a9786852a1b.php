

<?php $__env->startSection('title', 'Daftar User Google Workspace'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="mb-4">Daftar User Google Workspace</h1>

    
    <form method="GET" class="row g-3 mb-3">
        <div class="col-md-4">
            <input type="text" name="q" class="form-control" value="<?php echo e(request('q')); ?>"
                placeholder="Cari nama atau email...">
        </div>
        <div class="col-md-2">
            <button class="btn btn-outline-secondary w-100">Cari</button>
        </div>
    </form>

    
    <table class="table table-bordered bg-white shadow">
        <thead class="table-dark">
            <tr>
                <th>Email</th>
                <th>Nama</th>
                <th>Status</th>
                <th>Login Terakhir</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($user->getPrimaryEmail()); ?></td>
                    <td><?php echo e($user->getName()->getFullName()); ?></td>
                    <td>
                        <span class="badge <?php echo e($user->getSuspended() ? 'bg-danger' : 'bg-success'); ?>">
                            <?php echo e($user->getSuspended() ? 'Suspended' : 'Aktif'); ?>

                        </span>
                    </td>
                    <td><?php echo e($user->getLastLoginTime() ? \Carbon\Carbon::parse($user->getLastLoginTime())->format('d M Y H:i') : '-'); ?>

                    </td>
                    <td>
                        <a href="#" class="btn btn-sm btn-primary disabled">Detail</a>
                        <a href="#" class="btn btn-sm btn-warning disabled">Reset</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="text-center text-muted">Tidak ada data ditemukan.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    
    <?php if($users instanceof \Illuminate\Pagination\LengthAwarePaginator): ?>
        <?php echo e($users->links()); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Projects\reset-password\resources\views/admin/google-users/index.blade.php ENDPATH**/ ?>