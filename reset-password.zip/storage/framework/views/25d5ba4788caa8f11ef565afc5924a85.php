

<?php $__env->startSection('title', 'Edit Kelas'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="mb-3">
        Edit Kelas</h1>
    <a href="<?php echo e(route('kelas.index')); ?>" class="btn btn-secondary mb-3">← Kembali</a>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($e); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('kelas.update', $kelas->id)); ?>" method="POST" class="card p-4 shadow bg-white">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label class="form-label">Nama Kelas</label>
            <input type="text" name="nama_kelas" class="form-control" value="<?php echo e(old('nama_kelas', $kelas->nama_kelas)); ?>"
                required>
        </div>
        <div class="mb-3">
            <label class="form-label">Tingkat</label>
            <input type="text" name="tingkat_kelas" class="form-control"
                value="<?php echo e(old('tingkat_kelas', $kelas->tingkat_kelas)); ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Jurusan</label>
            <select name="jurusan_id" class="form-select" required>
                <option value="">-- Pilih Jurusan --</option>
                <?php $__currentLoopData = $jurusans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($j->id); ?>"
                        <?php echo e(old('jurusan_id', $kelas->jurusan_id) == $j->id ? 'selected' : ''); ?>><?php echo e($j->nama_jurusan); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <button type="submit" class="btn btn-success">Update</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Projects\reset-password\resources\views/kelas/edit.blade.php ENDPATH**/ ?>