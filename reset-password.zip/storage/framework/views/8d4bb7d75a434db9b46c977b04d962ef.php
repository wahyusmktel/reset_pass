<?php $__env->startSection('title', 'Detail Pengguna'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="mb-4">Detail Pengguna Google Workspace</h1>

    <div class="card shadow-sm">
        <div class="card-body d-flex">
            <img src="<?php echo e($user['photo_url'] ?? 'https://ui-avatars.com/api/?name=' . urlencode($user['name'])); ?>"
                class="rounded me-4" width="100" height="100" alt="Foto Profil">
            <div>
                <h4><?php echo e($user['name']); ?></h4>
                <p class="mb-1"><strong>Email:</strong> <?php echo e($user['email']); ?></p>
                <p class="mb-1"><strong>Admin:</strong> <?php echo e($user['is_admin'] ? 'Ya' : 'Tidak'); ?></p>
                <p class="mb-1"><strong>Status:</strong>
                    <span class="badge <?php echo e($user['suspended'] ? 'bg-danger' : 'bg-success'); ?>">
                        <?php echo e($user['suspended'] ? 'Suspended' : 'Aktif'); ?>

                    </span>
                </p>
                <p><strong>Terakhir Login:</strong>
                    <?php echo e($user['last_login'] ? \Carbon\Carbon::parse($user['last_login'])->format('d M Y H:i') : '-'); ?></p>
            </div>
        </div>
    </div>

    <a href="<?php echo e(route('admin.google.users')); ?>" class="btn btn-secondary mt-3">← Kembali</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Project Web\reset-password\resources\views/admin/google-users/show.blade.php ENDPATH**/ ?>