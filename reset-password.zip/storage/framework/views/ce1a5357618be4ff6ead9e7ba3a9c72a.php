

<?php $__env->startSection('title', 'Tambah Pengajuan Google'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="mb-3">
        Tambah Pengajuan Reset Google</h1>

    <a href="<?php echo e(route('pengajuan-google.index')); ?>" class="btn btn-secondary mb-3">← Kembali</a>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php echo $__env->make('pengajuan_google.form', [
        'action' => route('pengajuan-google.store'),
        'method' => 'POST',
        'button' => 'Simpan',
        'siswas' => $siswas,
        'data' => new \App\Models\PengajuanResetGoogle(),
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Projects\reset-password\resources\views/pengajuan_google/create.blade.php ENDPATH**/ ?>