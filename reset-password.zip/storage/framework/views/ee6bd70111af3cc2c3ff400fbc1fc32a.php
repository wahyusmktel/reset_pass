<?php $__env->startSection('title', 'Verifikasi OTP'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container py-5">
        <div class="card shadow p-4">
            <h3 class="mb-4">Verifikasi OTP</h3>

            <form method="POST" action="<?php echo e(route('pengajuan-google.verify-otp')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="siswa_id" value="<?php echo e($siswa->id); ?>">

                <div class="mb-3">
                    <label for="otp_code" class="form-label">Masukkan Kode OTP</label>
                    <input type="text" name="otp_code" id="otp_code"
                        class="form-control <?php $__errorArgs = ['otp_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    <?php $__errorArgs = ['otp_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <button class="btn btn-primary w-100">Verifikasi OTP</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('public.layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Project Web\reset-password\resources\views/public/pengajuan-google/verify-otp.blade.php ENDPATH**/ ?>