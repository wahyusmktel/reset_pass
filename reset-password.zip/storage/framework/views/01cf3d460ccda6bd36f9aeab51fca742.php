<?php $__env->startSection('title', 'Set Password Baru'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container py-5">
        <div class="card shadow p-4">
            <h3 class="mb-4">Reset Password untuk: <?php echo e($siswa->nama); ?></h3>

            
            <?php if(session('error')): ?>
                <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
            <?php endif; ?>

            <form action="<?php echo e(route('pengajuan-google.update-password', $pengajuan->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>

                
                <div class="mb-3">
                    <label class="form-label fw-semibold">Buat Password Baru</label>
                    <div class="input-group">
                        <input type="text" name="password" id="password"
                            class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('password')); ?>"
                            required>
                        <button type="button" class="btn btn-outline-secondary"
                            onclick="generatePassword()">Generate</button>
                        <button type="button" class="btn btn-outline-success" onclick="copyPassword()">Copy</button>
                    </div>
                    <small>Gunakan tombol <b>Generate</b> diatas untuk apabila anda ingin membuat password secara
                        random</small>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="mb-3">
                    <label class="form-label fw-semibold">Ketik Ulang Password Baru</label>
                    <input type="text" name="password_confirmation" id="password_confirmation"
                        class="form-control <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <button class="btn btn-primary w-100">Reset Password</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        function generatePassword() {
            const random = Math.random().toString(36).slice(-8);
            document.getElementById('password').value = random;
            document.getElementById('password_confirmation').value = random;
        }

        function copyPassword() {
            const input = document.getElementById('password');
            input.select();
            input.setSelectionRange(0, 99999);
            document.execCommand("copy");
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('public.layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Project Web\reset-password\resources\views/public/pengajuan-google/set-password.blade.php ENDPATH**/ ?>