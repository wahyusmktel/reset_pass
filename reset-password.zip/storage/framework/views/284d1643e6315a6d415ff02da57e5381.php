

<?php $__env->startSection('title', 'Data Siswa'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="mb-3">Data Siswa</h1>

    <a href="<?php echo e(route('siswa.create')); ?>" class="btn btn-primary mb-3">+ Tambah Siswa</a>
    <a href="<?php echo e(route('siswa.generate-akun-masal')); ?>" class="btn btn-success mb-3"
        onclick="return confirm('Yakin ingin generate akun semua siswa yang belum punya akun?')">
        🔁 Generate Akun Masal
    </a>

    <form action="<?php echo e(route('siswa.index')); ?>" method="GET" class="mb-3">
        <div class="input-group">
            <input type="text" name="q" value="<?php echo e(request('q')); ?>" class="form-control"
                placeholder="Cari nama, NIS, NISN, email...">
            <button class="btn btn-outline-secondary" type="submit">Cari</button>
        </div>
    </form>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php elseif(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered bg-white shadow">
        <thead class="table-dark">
            <tr>
                <th>Nama</th>
                <th>NIS</th>
                <th>NISN</th>
                <th>Email</th>
                <th>No HP</th>
                <th>Password</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $siswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($siswa->nama); ?></td>
                    <td><?php echo e($siswa->nis); ?></td>
                    <td><?php echo e($siswa->nisn); ?></td>
                    <td><?php echo e($siswa->email); ?></td>
                    <td><?php echo e($siswa->no_hp); ?></td>
                    <td><?php echo e($siswa->password); ?></td>
                    <td>
                        <a href="<?php echo e(route('siswa.edit', $siswa->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                        <form action="<?php echo e(route('siswa.destroy', $siswa->id)); ?>" method="POST" class="d-inline"
                            onsubmit="return confirm('Yakin ingin hapus?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger">Hapus</button>
                        </form>
                        <?php if($siswa->user): ?>
                            <form action="<?php echo e(route('siswa.reset-password', $siswa->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-sm btn-secondary"
                                    onclick="return confirm('Reset password untuk <?php echo e($siswa->nama); ?>?')">
                                    Reset Password
                                </button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="text-center">Data tidak ditemukan</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <?php echo e($siswas->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Projects\reset-password\resources\views/siswa/index.blade.php ENDPATH**/ ?>