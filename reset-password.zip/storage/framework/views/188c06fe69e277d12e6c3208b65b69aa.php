<form action="<?php echo e($action); ?>" method="POST" class="card p-4 shadow-sm bg-white">
    <?php echo csrf_field(); ?>
    <?php if($method === 'PUT'): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>

    <div class="mb-3">
        <label for="siswa_id" class="form-label">Siswa</label>
        <select name="siswa_id" id="siswa_id" class="form-select" required>
            <option value="">-- Pilih Siswa --</option>
            <?php $__currentLoopData = $siswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($siswa->id); ?>"
                    <?php echo e(old('siswa_id', $data->siswa_id ?? '') == $siswa->id ? 'selected' : ''); ?>>
                    <?php echo e($siswa->nama); ?> (<?php echo e($siswa->nis); ?>)
                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="mb-3">
        <label class="form-label">Keterangan</label>
        <input type="text" name="keterangan" class="form-control"
            value="<?php echo e(old('keterangan', $data->keterangan ?? '')); ?>" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Status Pengajuan</label>
        <select name="status_pengajuan" class="form-select" required>
            <option value="1"
                <?php echo e(old('status_pengajuan', $data->status_pengajuan ?? '') == 1 ? 'selected' : ''); ?>>Aktif</option>
            <option value="0"
                <?php echo e(old('status_pengajuan', $data->status_pengajuan ?? '') == 0 ? 'selected' : ''); ?>>Tidak Aktif
            </option>
        </select>
    </div>

    <button class="btn btn-primary"><?php echo e($button); ?></button>
</form>
<?php /**PATH G:\Project Web\reset-password\resources\views/pengajuan_google/form.blade.php ENDPATH**/ ?>