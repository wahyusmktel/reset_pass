

<?php $__env->startSection('title', 'Reset Akun iGracias'); ?>

<?php $__env->startSection('content'); ?>
    <h2 class="mb-4">Response Reset Akun iGracias</h2>

    <div class="card p-4 shadow-sm">
        <form action="<?php echo e(route('pengajuan-igracias.response.store', $pengajuan->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <p><strong>Nama:</strong> <?php echo e($pengajuan->siswa->nama); ?></p>
            <p><strong>Email:</strong> <?php echo e($pengajuan->siswa->email); ?></p>
            <p><strong>No HP:</strong> <?php echo e($pengajuan->siswa->no_hp); ?></p>

            <div class="mb-3">
                <label for="username_baru" class="form-label">Username Baru</label>
                <input type="text" name="username_baru" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="password_baru" class="form-label">Password Baru</label>
                <input type="text" name="password_baru" class="form-control" required>
            </div>

            <button class="btn btn-primary">Simpan Response</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Projects\reset-password\resources\views/pengajuan_igracias/reset.blade.php ENDPATH**/ ?>