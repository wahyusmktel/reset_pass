<?php $__env->startSection('title', 'Mapping Siswa Lokal dengan Google Workspace'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="mb-4">Mapping Siswa Lokal dengan Google Workspace</h1>

    <form method="POST" action="<?php echo e(route('admin.mapping-siswa.store')); ?>">
        <?php echo csrf_field(); ?>
        <table class="table table-bordered bg-white shadow">
            <thead class="table-dark">
                <tr>
                    <th>No</th>
                    <th>Nama Lokal</th>
                    <th>Nama Google</th>
                    <th>Email Google</th>
                    <th>Pilih</th>
                </tr>
            </thead>
            <tbody>
                

                <?php $__empty_1 = true; $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($i + 1); ?></td>
                        <td><?php echo e($item['siswa']->nama); ?></td>
                        <td>
                            <?php if($item['google']): ?>
                                <?php echo e($item['google']['name']); ?>

                            <?php else: ?>
                                <select class="form-select select-user" data-target="#mappingInput<?php echo e($item['siswa']->id); ?>">
                                    <option value="">-- Pilih Google User --</option>
                                    <?php $__currentLoopData = $googleUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $google): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($google['id']); ?>" data-email="<?php echo e($google['email']); ?>">
                                            <?php echo e($google['name']); ?> (<?php echo e($google['email']); ?>)
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($item['google']['email'] ?? '-'); ?></td>
                        <td>
                            <?php if($item['google']): ?>
                                <input type="checkbox" name="mapping[<?php echo e($item['siswa']->id); ?>]"
                                    value="<?php echo e($item['google']['email']); ?>">
                            <?php else: ?>
                                <input type="hidden" id="mappingInput<?php echo e($item['siswa']->id); ?>"
                                    name="mapping[<?php echo e($item['siswa']->id); ?>]">
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center text-muted">Tidak ada data untuk dicocokkan.</td>
                    </tr>
                <?php endif; ?>

            </tbody>
        </table>

        <button type="submit" class="btn btn-primary">Update Email Terpilih</button>
    </form>

    <?php $__env->startPush('styles'); ?>
        <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <?php $__env->stopPush(); ?>

    <?php $__env->startPush('scripts'); ?>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                $('.select-user').select2({
                    width: '100%',
                    placeholder: 'Pilih akun Google...'
                });

                // Sync value email ke input hidden saat select berubah
                $('.select-user').on('change', function() {
                    const selectedOption = $(this).find(':selected');
                    const email = selectedOption.data('email');
                    const inputTarget = $(this).data('target');
                    $(inputTarget).val(email);
                });
            });
        </script>
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Project Web\reset-password\resources\views/admin/mapping-siswa/index.blade.php ENDPATH**/ ?>