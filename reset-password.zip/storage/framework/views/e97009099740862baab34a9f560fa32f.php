

<?php $__env->startSection('title', 'Data Kelas'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="mb-3">Data Kelas</h1>

    <a href="<?php echo e(route('kelas.create')); ?>" class="btn btn-primary mb-3">+ Tambah Kelas</a>

    <form action="<?php echo e(route('kelas.index')); ?>" method="GET" class="mb-3">
        <div class="input-group">
            <input type="text" name="q" value="<?php echo e(request('q')); ?>" class="form-control"
                placeholder="Cari nama/tingkat kelas...">
            <button class="btn btn-outline-secondary" type="submit">Cari</button>
        </div>
    </form>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php elseif(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered bg-white shadow">
        <thead class="table-dark">
            <tr>
                <th>Nama Kelas</th>
                <th>Tingkat</th>
                <th>Jurusan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($k->nama_kelas); ?></td>
                    <td><?php echo e($k->tingkat_kelas); ?></td>
                    <td><?php echo e($k->jurusan->nama_jurusan ?? '-'); ?></td>
                    <td>
                        <a href="<?php echo e(route('kelas.edit', $k->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                        <form action="<?php echo e(route('kelas.destroy', $k->id)); ?>" method="POST" class="d-inline"
                            onsubmit="return confirm('Yakin hapus?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger">Hapus</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4" class="text-center">Tidak ada data</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <?php echo e($kelas->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Project Web\reset-password\resources\views/kelas/index.blade.php ENDPATH**/ ?>