 

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="mb-4">Reset Password Akun Google Siswa</h2>

        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <form action="<?php echo e(route('admin.reset-google-password')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="email" class="form-label">Email Siswa</label>
                <input type="email" name="email" class="form-control" required
                    placeholder="contoh: siswa@smktelkom-lpg.sch.id">
            </div>

            <div class="mb-3">
                <label for="password" class="form-label">Password Baru</label>
                <input type="text" name="password" class="form-control" required placeholder="Minimal 6 karakter">
            </div>

            <button type="submit" class="btn btn-danger">Reset Password</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Project Web\reset-password\resources\views/admin/reset-password-google.blade.php ENDPATH**/ ?>