

<?php $__env->startSection('title', 'Edit Siswa'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="mb-3">Edit Siswa</h1>

    <a href="<?php echo e(route('siswa.index')); ?>" class="btn btn-secondary mb-3">← Kembali</a>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('siswa.update', $siswa->id)); ?>" method="POST" class="card p-4 shadow bg-white">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label class="form-label">Nama</label>
            <input type="text" name="nama" class="form-control" value="<?php echo e(old('nama', $siswa->nama)); ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">NIS</label>
            <input type="text" name="nis" class="form-control" value="<?php echo e(old('nis', $siswa->nis)); ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">NISN</label>
            <input type="text" name="nisn" class="form-control" value="<?php echo e(old('nisn', $siswa->nisn)); ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Email</label>
            <input type="email" name="email" class="form-control" value="<?php echo e(old('email', $siswa->email)); ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">No HP</label>
            <input type="text" name="no_hp" class="form-control" value="<?php echo e(old('no_hp', $siswa->no_hp)); ?>" required>
        </div>
        <button type="submit" class="btn btn-success">Update</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Projects\reset-password\resources\views/siswa/edit.blade.php ENDPATH**/ ?>