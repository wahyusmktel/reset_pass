

<?php $__env->startSection('title', 'Siswa per Rombel'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="mb-3">Lihat Siswa per Rombel</h1>

    <form action="<?php echo e(route('rombel.per-kelas')); ?>" method="GET" class="card p-3 shadow-sm mb-4 bg-white">
        <div class="row g-2 align-items-end">
            <div class="col-md-8">
                <label for="kelas_id" class="form-label">Pilih Kelas / Rombel</label>
                <select name="kelas_id" id="kelas_id" class="form-select" required>
                    <option value="">-- Pilih Kelas --</option>
                    <?php $__currentLoopData = $kelasList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kls): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($kls->id); ?>" <?php echo e($selectedKelasId == $kls->id ? 'selected' : ''); ?>>
                            <?php echo e($kls->tingkat_kelas); ?> - <?php echo e($kls->nama_kelas); ?> (<?php echo e($kls->jurusan->nama_jurusan ?? '-'); ?>)
                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-4">
                <button type="submit" class="btn btn-primary w-100">Tampilkan</button>
            </div>
        </div>
    </form>

    <?php if($kelasTerpilih): ?>
        <div class="card shadow">
            <div class="card-header bg-dark text-white">
                <strong><?php echo e($kelasTerpilih->tingkat_kelas); ?> - <?php echo e($kelasTerpilih->nama_kelas); ?></strong>
                <span class="badge bg-secondary float-end"><?php echo e($kelasTerpilih->jurusan->nama_jurusan ?? '-'); ?></span>
            </div>
            <div class="card-body p-0">
                <?php if($rombels->count() > 0): ?>
                    <table class="table table-striped mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th>Nama Siswa</th>
                                <th>NIS</th>
                                <th>NISN</th>
                                <th>Email</th>
                                <th>No HP</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $rombels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $rombel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><?php echo e($rombel->siswa->nama); ?></td>
                                    <td><?php echo e($rombel->siswa->nis); ?></td>
                                    <td><?php echo e($rombel->siswa->nisn); ?></td>
                                    <td><?php echo e($rombel->siswa->email); ?></td>
                                    <td><?php echo e($rombel->siswa->no_hp); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="p-3 text-muted">Belum ada siswa di kelas ini.</div>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Projects\reset-password\resources\views/rombel/per_kelas.blade.php ENDPATH**/ ?>