

<?php $__env->startSection('title', 'Data Rombel'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="mb-3">Data Rombel</h1>

    <a href="<?php echo e(route('rombel.create')); ?>" class="btn btn-primary mb-3">+ Tambah Rombel</a>
    <a href="<?php echo e(route('rombel.generate')); ?>" class="btn btn-primary mb-3">
        <i class="fas fa-magic me-1"></i> Generate Rombel Otomatis
    </a>

    <form action="<?php echo e(route('rombel.index')); ?>" method="GET" class="mb-3">
        <div class="input-group">
            <input type="text" name="q" value="<?php echo e(request('q')); ?>" class="form-control"
                placeholder="Cari nama siswa atau kelas...">
            <button class="btn btn-outline-secondary" type="submit">Cari</button>
        </div>
    </form>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php elseif(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered bg-white shadow">
        <thead class="table-dark">
            <tr>
                <th>Nama Siswa</th>
                <th>Kelas</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $rombels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rombel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($rombel->siswa->nama ?? '-'); ?></td>
                    <td><?php echo e($rombel->kelas->nama_kelas ?? '-'); ?></td>
                    <td>
                        <a href="<?php echo e(route('rombel.edit', $rombel->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                        <form action="<?php echo e(route('rombel.destroy', $rombel->id)); ?>" method="POST" class="d-inline"
                            onsubmit="return confirm('Yakin hapus?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger">Hapus</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3" class="text-center">Data tidak ditemukan</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <?php echo e($rombels->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Projects\reset-password\resources\views/rombel/index.blade.php ENDPATH**/ ?>