

<?php $__env->startSection('title', 'Pengajuan Reset Google'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="mb-4">Data Pengajuan Reset Google</h1>

    <a href="<?php echo e(route('pengajuan-google.create')); ?>" class="btn btn-primary mb-3">+ Tambah Pengajuan</a>

    <form method="GET" class="row g-3 mb-3">
        <div class="col-md-4">
            <input type="text" name="q" value="<?php echo e(request('q')); ?>" class="form-control"
                placeholder="Cari nama siswa...">
        </div>
        <div class="col-md-3">
            <select name="status_pengajuan" class="form-select">
                <option value="">-- Semua Status Pengajuan --</option>
                <option value="1" <?php echo e(request('status_pengajuan') === '1' ? 'selected' : ''); ?>>Diajukan</option>
                <option value="0" <?php echo e(request('status_pengajuan') === '0' ? 'selected' : ''); ?>>Response</option>
            </select>
        </div>
        <div class="col-md-3">
            <select name="status_wa" class="form-select">
                <option value="">-- Semua Status WA --</option>
                <option value="1" <?php echo e(request('status_wa') === '1' ? 'selected' : ''); ?>>Sudah Kirim WA</option>
                <option value="0" <?php echo e(request('status_wa') === '0' ? 'selected' : ''); ?>>Belum Kirim WA</option>
            </select>
        </div>
        <div class="col-md-2">
            <button class="btn btn-outline-secondary w-100" type="submit">Filter</button>
        </div>
    </form>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php elseif(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered bg-white shadow">
        <thead class="table-dark">
            <tr>
                <th>Nama Siswa</th>
                <th>Keterangan</th>
                <th>Status Pengajuan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->siswa->nama ?? '-'); ?></td>
                    <td><?php echo e($item->keterangan); ?></td>
                    <td>
                        <?php if($item->status_pengajuan): ?>
                            <span class="badge bg-success">Diajukan</span>
                        <?php else: ?>
                            <span class="badge bg-secondary">Response</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('pengajuan-google.edit', $item->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                        <a href="<?php echo e(route('pengajuan-google.response.form', $item->id)); ?>"
                            class="btn btn-sm btn-success">Reset</a>
                        <form action="<?php echo e(route('pengajuan-google.destroy', $item->id)); ?>" method="POST" class="d-inline"
                            onsubmit="return confirm('Yakin hapus?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger">Hapus</button>
                        </form>
                        <?php if(!$item->status_pengajuan && $item->siswa && $item->response && !$item->response->sudah_kirim_wa): ?>
                            <?php
                                $hp = ltrim($item->siswa->no_hp, '0');
                                $wa = '62' . $hp;

                                $message = urlencode("
Halo, berikut ini adalah akun Google sekolah Anda yang telah direset:

Nama: {$item->siswa->nama}
NIS: {$item->siswa->nis}
Email Baru: {$item->response->email_baru}
Password Baru: {$item->response->password_baru}

Silakan login menggunakan akun di atas. Jika ada kendala, segera hubungi admin.
");
                                $waLink = "https://api.whatsapp.com/send?phone=$wa&text=$message";
                            ?>

                            <form action="<?php echo e(route('pengajuan-google.kirim-wa', $item->id)); ?>" method="POST"
                                class="d-inline">
                                <?php echo csrf_field(); ?>
                                <a href="<?php echo e($waLink); ?>" target="_blank" class="btn btn-sm btn-outline-success">Kirim
                                    WA</a>
                                <button type="submit" class="btn btn-sm btn-outline-secondary"
                                    onclick="return confirm('Tandai sebagai sudah kirim WA?')">
                                    ✔ Tandai Kirim WA
                                </button>
                            </form>
                        <?php elseif($item->response && $item->response->sudah_kirim_wa): ?>
                            <span class="badge bg-success">Sudah Kirim WA</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php echo e($data->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Projects\reset-password\resources\views/pengajuan_google/index.blade.php ENDPATH**/ ?>