

<?php $__env->startSection('title', 'Generate Akun Siswa'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="mb-4">Generate Akun Login Siswa</h1>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php elseif(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <form action="<?php echo e(route('akun-siswa.generate')); ?>" method="POST" class="card p-4 shadow-sm bg-white mb-4">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="siswa_id" class="form-label">Pilih Siswa</label>
            <select name="siswa_id" class="form-select" required>
                <option value="">-- Pilih Siswa --</option>
                <?php $__currentLoopData = $siswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($siswa->id); ?>"><?php echo e($siswa->nama); ?> (<?php echo e($siswa->nis); ?>)</option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Password Akun</label>
            <input type="text" name="password" class="form-control" placeholder="Minimal 6 karakter" required>
        </div>
        <button class="btn btn-primary">Generate Akun</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Projects\reset-password\resources\views/akun_siswa/index.blade.php ENDPATH**/ ?>