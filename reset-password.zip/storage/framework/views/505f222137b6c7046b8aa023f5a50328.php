

<?php $__env->startSection('title', 'Pengajuan Reset iGracias'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="mb-4">Data Pengajuan Reset iGracias</h1>

    <form method="GET" class="row g-3 mb-3">
        <div class="col-md-4">
            <input type="text" name="q" class="form-control" value="<?php echo e(request('q')); ?>"
                placeholder="Cari nama siswa...">
        </div>
        <div class="col-md-3">
            <select name="status_pengajuan" class="form-select">
                <option value="">-- Semua Status Pengajuan --</option>
                <option value="1" <?php echo e(request('status_pengajuan') === '1' ? 'selected' : ''); ?>>Diajukan</option>
                <option value="0" <?php echo e(request('status_pengajuan') === '0' ? 'selected' : ''); ?>>Response</option>
            </select>
        </div>
        <div class="col-md-3">
            <select name="status_wa" class="form-select">
                <option value="">-- Semua Status WA --</option>
                <option value="1" <?php echo e(request('status_wa') === '1' ? 'selected' : ''); ?>>Sudah Kirim WA</option>
                <option value="0" <?php echo e(request('status_wa') === '0' ? 'selected' : ''); ?>>Belum Kirim WA</option>
            </select>
        </div>
        <div class="col-md-2">
            <button class="btn btn-outline-secondary w-100">Filter</button>
        </div>
    </form>

    <table class="table table-bordered bg-white shadow">
        <thead class="table-dark">
            <tr>
                <th>Nama Siswa</th>
                <th>Keterangan</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->siswa->nama ?? '-'); ?></td>
                    <td><?php echo e($item->keterangan); ?></td>
                    <td>
                        <span class="badge <?php echo e($item->status_pengajuan ? 'bg-success' : 'bg-secondary'); ?>">
                            <?php echo e($item->status_pengajuan ? 'Diajukan' : 'Response'); ?>

                        </span>
                    </td>
                    <td>
                        <a href="<?php echo e(route('pengajuan-igracias.response.form', $item->id)); ?>"
                            class="btn btn-sm btn-success">Reset</a>

                        <?php if(!$item->status_pengajuan && $item->response && !$item->response->sudah_kirim_wa): ?>
                            <?php
                                $hp = ltrim($item->siswa->no_hp, '0');
                                $wa = '62' . $hp;
                                $message = urlencode("
Halo, berikut akun iGracias Anda yang telah direset:

Nama: {$item->siswa->nama}
NIS: {$item->siswa->nis}
Username Baru: {$item->response->username_baru}
Password Baru: {$item->response->password_baru}

Silakan login dan jaga kerahasiaan akun Anda.
");
                                $waLink = "https://api.whatsapp.com/send?phone=$wa&text=$message";
                            ?>
                            <form action="<?php echo e(route('pengajuan-igracias.kirim-wa', $item->id)); ?>" method="POST"
                                class="d-inline">
                                <?php echo csrf_field(); ?>
                                <a href="<?php echo e($waLink); ?>" target="_blank" class="btn btn-sm btn-outline-success">Kirim
                                    WA</a>
                                <button type="submit" class="btn btn-sm btn-outline-secondary"
                                    onclick="return confirm('Tandai sebagai sudah kirim WA?')">✔ Tandai Kirim WA</button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php echo e($data->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Projects\reset-password\resources\views/pengajuan_igracias/index.blade.php ENDPATH**/ ?>