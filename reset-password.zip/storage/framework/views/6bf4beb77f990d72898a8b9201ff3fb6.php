

<?php $__env->startSection('title', 'Data Jurusan'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="mb-3">Data Jurusan</h1>

    <a href="<?php echo e(route('jurusan.create')); ?>" class="btn btn-primary mb-3">+ Tambah Jurusan</a>

    <form action="<?php echo e(route('jurusan.index')); ?>" method="GET" class="mb-3">
        <div class="input-group">
            <input type="text" name="q" value="<?php echo e(request('q')); ?>" class="form-control"
                placeholder="Cari nama atau kode jurusan...">
            <button class="btn btn-outline-secondary" type="submit">Cari</button>
        </div>
    </form>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php elseif(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered bg-white shadow">
        <thead class="table-dark">
            <tr>
                <th>Nama Jurusan</th>
                <th>Kode</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $jurusans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurusan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($jurusan->nama_jurusan); ?></td>
                    <td><?php echo e($jurusan->kode_jurusan); ?></td>
                    <td>
                        <a href="<?php echo e(route('jurusan.edit', $jurusan->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                        <form action="<?php echo e(route('jurusan.destroy', $jurusan->id)); ?>" method="POST" class="d-inline"
                            onsubmit="return confirm('Yakin hapus?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger">Hapus</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3" class="text-center">Tidak ada data</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <?php echo e($jurusans->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Projects\reset-password\resources\views/jurusan/index.blade.php ENDPATH**/ ?>